# python_module_7HW
 
